# Node.js App with Authentication and Pagination

## To Run Locally:

1. Clone the repository.
2. Run `npm install`.
3. Run `npm start` or `node server.js`.
4. Visit `http://localhost:3000` in your browser.

## Login details:
check users.json file to select login detail

